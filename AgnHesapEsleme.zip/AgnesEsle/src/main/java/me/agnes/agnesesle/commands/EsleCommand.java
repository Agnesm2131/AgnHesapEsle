package me.agnes.agnesesle.commands;

import me.agnes.agnesesle.AgnesEsle;
import me.agnes.agnesesle.data.EslestirmeManager;
import me.agnes.agnesesle.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;

public class EsleCommand implements CommandExecutor, TabCompleter {

    private final int PAGE_SIZE = 10;
    private final List<String> ALT_KOMUTLAR = Arrays.asList(
            "eşle", "onayla", "iptal", "kaldir", "liste", "sifirla", "yenile"
    );

    private void playSuccess(Player p) {
        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1f);
    }

    private void playError(Player p) {
        p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Bu komut sadece oyuncular için.");
            return true;
        }

        if (args.length < 1) {
            playError(p);
            MessageUtil.sendTitle(p, "hatalı-kullanim");
            return true;
        }

        String altKomut = args[0].toLowerCase();
        switch (altKomut) {
            case "eşle":
                if (EslestirmeManager.eslesmeVar(p.getUniqueId())) {
                    playError(p);
                    MessageUtil.sendTitle(p, "hesap-zaten-eslesmis");
                    return true;
                }
                String kod = EslestirmeManager.uretKod(p.getUniqueId());
                if (kod == null) {
                    playError(p);
                    MessageUtil.sendTitle(p, "kod-lutfen-bekleyin");
                    return true;
                }
                playSuccess(p);
                Map<String, String> vars = new HashMap<>();
                vars.put("kod", kod);
                MessageUtil.sendTitle(p, "kod-verildi", vars);
                break;

            case "iptal":
                if (!EslestirmeManager.beklemeVar(p.getUniqueId())) {
                    playError(p);
                    MessageUtil.sendTitle(p, "eslesme-onayi-beklemiyor");
                    return true;
                }
                EslestirmeManager.iptalEt(p.getUniqueId());
                playSuccess(p);
                MessageUtil.sendTitle(p, "hesap-esle-kodiptal");
                break;

            case "onayla":
                if (!EslestirmeManager.beklemeVar(p.getUniqueId())) {
                    playError(p);
                    MessageUtil.sendTitle(p, "eslesme-onayi-beklemiyor");
                    return true;
                }
                boolean ilkEslesme = !EslestirmeManager.eslesmeVar(p.getUniqueId());
                boolean onaylandi = EslestirmeManager.onaylaEslesme(p.getUniqueId());
                if (!onaylandi) {
                    playError(p);
                    MessageUtil.sendTitle(p, "eslesme-onaylanamadi");
                    return true;
                }
                playSuccess(p);
                MessageUtil.sendTitle(p, "eslesme-basariyla-tamamlandi");

                if (ilkEslesme) {
                    Bukkit.getScheduler().runTask(AgnesEsle.getInstance(), () -> {
                        for (String cmd : AgnesEsle.getInstance().getConfig().getStringList("oduller")) {
                            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", p.getName()));
                        }
                        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
                        p.getWorld().spawnParticle(org.bukkit.Particle.VILLAGER_HAPPY, p.getLocation().add(0,1,0), 15,0.5,0.5,0.5);
                    });
                }
                break;

            case "kaldir":
                if (!EslestirmeManager.eslesmeVar(p.getUniqueId())) {
                    playError(p);
                    MessageUtil.sendTitle(p, "eslesme-yok");
                    return true;
                }
                EslestirmeManager.kaldirEslesme(p.getUniqueId());
                playSuccess(p);
                MessageUtil.sendTitle(p, "kaldirildi");
                break;

            case "liste":
                if (!p.hasPermission("agnesesle.admin")) {
                    playError(p);
                    MessageUtil.sendTitle(p, "yetki-yok");
                    return true;
                }
                Map<UUID,String> eslesmeler = EslestirmeManager.getTumEslesmeler();
                if (eslesmeler.isEmpty()) {
                    playError(p);
                    p.sendMessage("§cHenüz eşleşme yok.");
                    return true;
                }

                int toplam = eslesmeler.size();
                int maxPage = (toplam + PAGE_SIZE - 1) / PAGE_SIZE;
                int page = 1;
                if (args.length > 1) {
                    try { page = Math.max(Integer.parseInt(args[1]),1); } catch (NumberFormatException ignored){}
                }
                if (page>maxPage) page=maxPage;

                p.sendMessage("§6---- [Eşleşme Listesi Sayfa "+page+"/"+maxPage+"] ----");
                UUID[] uuids = eslesmeler.keySet().toArray(new UUID[0]);
                int start=(page-1)*PAGE_SIZE;
                int end=Math.min(start+PAGE_SIZE,toplam);
                for(int i=start;i<end;i++){
                    UUID uuid=uuids[i];
                    String id=eslesmeler.get(uuid);
                    OfflinePlayer op=Bukkit.getOfflinePlayer(uuid);
                    String ad=op.getName()!=null?op.getName():"Bilinmiyor";
                    p.sendMessage("§e"+ad+" §7- Discord ID: §a"+id);
                }
                if(maxPage>1) p.sendMessage("§7Sayfa değiştirmek için: /hesapeşle liste <sayfa>");
                playSuccess(p);
                break;

            case "sifirla":
                if (!p.hasPermission("agnesesle.admin")) {
                    playError(p);
                    MessageUtil.sendTitle(p, "yetki-yok");
                    return true;
                }
                if (args.length < 2) {
                    playError(p);
                    MessageUtil.sendTitle(p, "hatalı-kullanim");
                    return true;
                }
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                if (target == null || !target.hasPlayedBefore()) {
                    playError(p);
                    MessageUtil.sendTitle(p, "oyuncu-bulunamadi");
                    return true;
                }
                UUID targetUUID = target.getUniqueId();
                if (!EslestirmeManager.eslesmeVar(targetUUID)) {
                    playError(p);
                    MessageUtil.sendTitle(p, "eslesme-yok");
                    return true;
                }
                EslestirmeManager.kaldirEslesme(targetUUID);
                playSuccess(p);
                p.sendMessage("§a" + target.getName() + " isimli oyuncunun eşleşmesi sıfırlandı.");
                break;

            case "yenile":
                MessageUtil.yenile();
                playSuccess(p);
                MessageUtil.sendTitle(p, "yenilendi");
                break;

            default:
                playError(p);
                MessageUtil.sendTitle(p, "bilinmeyen-komut");
        }

        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if(args.length==1) return ALT_KOMUTLAR;
        return Collections.emptyList();
    }
}
