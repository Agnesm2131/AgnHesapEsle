package me.agnes.agnesesle.data;

import me.agnes.agnesesle.AgnesEsle;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.*;
import java.lang.reflect.Type;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class EslestirmeManager {

    private static final Map<String, UUID> kodlar = new ConcurrentHashMap<>();
    private static final Map<UUID, String> eslesmeler = new ConcurrentHashMap<>();
    private static final Map<UUID, String> bekleyenEslesmeler = new ConcurrentHashMap<>();

    private static final Map<String, UUID> bekleyenKodlar = new ConcurrentHashMap<>();
    private static final Map<String, Long> kodZamanları = new ConcurrentHashMap<>();

    private static final Set<UUID> odulVerilenler = ConcurrentHashMap.newKeySet();

    private static final File dataFile = new File(AgnesEsle.getInstance().getDataFolder(), "data.json");
    private static final Gson gson = new Gson();

    public static void init() {
        loadEslesmeler();
    }

    public static String uretKod(UUID uuid) {
        String kod = UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        kodlar.put(kod, uuid);
        bekleyenKodlar.put(kod, uuid);
        kodZamanları.put(kod, System.currentTimeMillis());
        return kod;
    }

    public static UUID koduKontrolEt(String kod) {
        return kodlar.getOrDefault(kod.toUpperCase(), null);
    }

    public static boolean eslestir(UUID uuid, String discordId) {
        if (eslesmeler.containsValue(discordId) || bekleyenEslesmeler.containsValue(discordId)) {
            return false;
        }
        bekleyenEslesmeler.put(uuid, discordId);
        return true;
    }

    public static boolean onaylaEslesme(UUID uuid) {
        String discordId = bekleyenEslesmeler.remove(uuid);
        if (discordId == null) return false;

        eslesmeler.put(uuid, discordId);
        kodlar.values().remove(uuid);
        bekleyenKodlar.values().remove(uuid);

        saveEslesmeler();
        return true;
    }

    public static boolean beklemeVar(UUID uuid) {
        return bekleyenEslesmeler.containsKey(uuid);
    }

    public static String bekleyenDiscordId(UUID uuid) {
        return bekleyenEslesmeler.get(uuid);
    }

    public static void kaldirEslesme(UUID uuid) {
        eslesmeler.remove(uuid);
        odulVerilenler.remove(uuid);
        saveEslesmeler();
    }

    public static Map<UUID, String> getTumEslesmeler() {
        return eslesmeler;
    }

    public static boolean eslesmeVar(UUID uuid) {
        return eslesmeler.containsKey(uuid);
    }

    public static boolean discordZatenEslesmis(String discordId) {
        return eslesmeler.containsValue(discordId) || bekleyenEslesmeler.containsValue(discordId);
    }

    public static String discordId(UUID uuid) {
        return eslesmeler.get(uuid);
    }

    public static boolean iptalEt(UUID uuid) {
        if (bekleyenKodlar.containsValue(uuid)) {
            String kod = null;
            for (Map.Entry<String, UUID> entry : bekleyenKodlar.entrySet()) {
                if (entry.getValue().equals(uuid)) {
                    kod = entry.getKey();
                    break;
                }
            }
            if (kod != null) {
                kodlar.remove(kod);
                bekleyenKodlar.remove(kod);
                kodZamanları.remove(kod);
                return true;
            }
        }
        return false;
    }

    public static boolean odulVerildiMi(UUID uuid) {
        return odulVerilenler.contains(uuid);
    }

    public static void odulVerildi(UUID uuid) {
        odulVerilenler.add(uuid);
    }

    public static String getDiscordId(UUID uuid) {
        return eslesmeler.get(uuid);
    }
    public static UUID getUUIDByDiscordId(String discordId) {
        for (Map.Entry<UUID, String> entry : eslesmeler.entrySet()) {
            if (entry.getValue().equals(discordId)) {
                return entry.getKey();
            }
        }
        return null;
    }


    private static void loadEslesmeler() {
        if (!dataFile.exists()) return;

        try (Reader reader = new FileReader(dataFile)) {
            Type type = new TypeToken<Map<UUID, String>>() {}.getType();
            Map<UUID, String> veriler = gson.fromJson(reader, type);
            if (veriler != null) eslesmeler.putAll(veriler);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void saveEslesmeler() {
        try (Writer writer = new FileWriter(dataFile)) {
            gson.toJson(eslesmeler, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
