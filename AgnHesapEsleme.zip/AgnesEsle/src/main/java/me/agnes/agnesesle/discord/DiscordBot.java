package me.agnes.agnesesle.discord;

import me.agnes.agnesesle.AgnesEsle;
import me.agnes.agnesesle.discord.listener.EslestirmeKomutu;
import net.dv8tion.jda.api.*;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;


import net.dv8tion.jda.api.EmbedBuilder;


import java.awt.*;
import java.util.concurrent.*;

public class DiscordBot {

    private final String token;
    private JDA jda;
    private ScheduledExecutorService scheduler;

    public DiscordBot(String token) {
        this.token = token;
    }

    public void start() {
        try {
            jda = JDABuilder.createDefault(token)
                    .setActivity(Activity.playing("Başlatılıyor..."))
                    .build()
                    .awaitReady();

            jda.upsertCommand("eşle", "Minecraft hesabını eşleştir")
                    .addOption(net.dv8tion.jda.api.interactions.commands.OptionType.STRING, "kod", "Eşleştirme kodun", true)
                    .queue();


            jda.addEventListener(new EslestirmeKomutu());

            String[] durumlar = AgnesEsle.getInstance().getConfig().getStringList("durum-mesajlari").toArray(new String[0]);
            scheduler = Executors.newSingleThreadScheduledExecutor();
            scheduler.scheduleAtFixedRate(new Runnable() {
                int i = 0;
                public void run() {
                    jda.getPresence().setActivity(Activity.playing(durumlar[i]));
                    i = (i + 1) % durumlar.length;
                }
            }, 0, 5, TimeUnit.SECONDS);

            String kanalId = AgnesEsle.getInstance().getConfig().getString("discord.bilgilendirme-kanal-id");
            TextChannel kanal = jda.getTextChannelById(kanalId);
            if (kanal != null) {
                EmbedBuilder embed = new EmbedBuilder()
                        .setTitle("📘 AgnEşle - Hesap Eşleştirme Bilgilendirmesi")
                        .setColor(new Color(0x2F3136))
                        .addField("🔐 NASIL HESABIMI EŞLERİM ❓", """
                        • Sunucumuza giriş yapıp, **/hesapeşle eşle** komutunu kullandıktan sonra size verilen sohbetteki kodu
                        bu kanala gelip **/eşle [kod]** şeklinde yazdıktan sonra oyun içinden hesabınızı eşlemek istediğinizi onaylamanız gerekmektedir.
                        • Oyun içerisinden **/hesapeşle onayla** yazarak eşleme işlemini tamamlamış olursunuz.
                        """, false)
                        .addField("🎁 ÖDÜLLER VE DİĞER", """
                        • Discord kullanıcı adınız, oyun içindeki kullanıcı adınız ile değiştirilir.
                        • 3 adet kasa anahtarı oyun içi ödül olarak verilir.
                        • <@&1398323780472017006> rolü kullanıcıya atanır.
                        • Ödüller sadece ilk eşleşmede verilir.
                        """, false)
                        .addField("📜 DİĞER KOMUTLAR", """
                        • **/hesapeşle kaldır**: Hesap eşlemesini kaldırır.
                        • **/hesapeşle onayla**: Kodu yazdıktan sonra işlemi onaylamak için.
                        • **/hesapeşle kodiptal**: Onay işlemindeyken kodu iptal etmek için.
                        """, false)
                        .setFooter("AgnHesapEşleme Sistemi", null);

                kanal.sendMessageEmbeds(embed.build()).queue();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void shutdown() {
        if (jda != null) jda.shutdownNow();
        if (scheduler != null) scheduler.shutdownNow();
    }

    public JDA getJda() {
        return jda;
    }
}
