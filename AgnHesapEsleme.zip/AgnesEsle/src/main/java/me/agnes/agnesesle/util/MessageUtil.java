package me.agnes.agnesesle.util;

import me.agnes.agnesesle.AgnesEsle;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.Map;

public class MessageUtil {

    private static FileConfiguration messages;

    public static void yenile() {
        File file = new File(AgnesEsle.getInstance().getDataFolder(), "messages.yml");
        if (!file.exists()) {
            AgnesEsle.getInstance().saveResource("messages.yml", false);
        }
        messages = YamlConfiguration.loadConfiguration(file);
    }

    public static void sendTitle(Player p, String path, Map<String, String> vars) {
        if (messages == null) yenile();

        String title = messages.getString(path + ".title", "§cBaşlık Bulunamadı");
        String subtitle = messages.getString(path + ".subtitle", "§7Alt başlık bulunamadı");

        if (vars != null) {
            for (Map.Entry<String, String> entry : vars.entrySet()) {
                title = title.replace("%" + entry.getKey() + "%", entry.getValue());
                subtitle = subtitle.replace("%" + entry.getKey() + "%", entry.getValue());
            }
        }

        p.sendTitle(title, subtitle, 10, 70, 20);
    }

    public static void sendTitle(Player p, String path) {
        sendTitle(p, path, null);
    }
}
