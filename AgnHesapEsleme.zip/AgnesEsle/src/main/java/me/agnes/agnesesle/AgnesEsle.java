package me.agnes.agnesesle;

import me.agnes.agnesesle.commands.EsleCommand;
import me.agnes.agnesesle.data.EslestirmeManager;
import me.agnes.agnesesle.discord.DiscordBot;
import org.bukkit.plugin.java.JavaPlugin;

public class AgnesEsle extends JavaPlugin {

    private static AgnesEsle instance;
    private DiscordBot discordBot;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        saveResource("messages.yml", false);

        EsleCommand esleCommand = new EsleCommand();

        // Burada plugin.yml'deki komut ismini kullanmalısın:
        if (getCommand("hesapesle") != null) {
            getCommand("hesapesle").setExecutor(esleCommand);
            getCommand("hesapesle").setTabCompleter(esleCommand);
        } else {
            getLogger().severe("Komut bulunamadı: hesapesle!");
        }

        EslestirmeManager.init();

        discordBot = new DiscordBot(getConfig().getString("token"));
        discordBot.start();
    }

    @Override
    public void onDisable() {
        if (discordBot != null) discordBot.shutdown();
    }

    public static AgnesEsle getInstance() {
        return instance;
    }

    public DiscordBot getDiscordBot() {
        return discordBot;
    }
}
